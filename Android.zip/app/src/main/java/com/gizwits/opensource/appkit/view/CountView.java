package com.gizwits.opensource.appkit.view;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gizwits.opensource.appkit.R;


/**
 * Created by Pan on 2017/10/8 0030 15:41
 * Desc: 增加减少数量控件
 */

public class CountView extends LinearLayout implements View.OnClickListener {
    private Context mContext;
    private EditText mCount_result;
    private ImageView add;
    private ImageView reduce;
    private int count = 1;
    private OnClick mClick;
    private String max;
    private String min;
    private String input;
    private boolean mRefelect = true;

    public CountView(Context context) {
        this(context, null);
    }

    public CountView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CountView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        View view = LayoutInflater.from(context).inflate(R.layout.count_view_layout, this, true);
        //增加
        add = (ImageView) view.findViewById(R.id.increase_goods_Num);
        //减少
        reduce = (ImageView) view.findViewById(R.id.reduce_goodsNum);
        add.setOnClickListener(this);
        reduce.setOnClickListener(this);
        //计数
        mCount_result = (EditText) view.findViewById(R.id.change_number);

        initListener();
    }

    private void initListener() {
        mCount_result.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                input = s.toString();
                if (!input.isEmpty()) {
                    mCount_result.setSelection(input.length());
                    count = Integer.parseInt(input);
                    if (count > Integer.parseInt(max)) {
                        count = Integer.parseInt(max);
                        mCount_result.setText(max);
                    }
                    if (mRefelect) {
                        mClick.onClick(CountView.this, count);
                    }
                }
            }
        });

        mCount_result.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (input != null) {
                    mClick.onClick(CountView.this, Integer.parseInt(input));
                }
                return true;
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.increase_goods_Num:
                reduce.setSelected(false);
                if (max != null && count < Integer.parseInt(max)) {
                    add.setSelected(false);
                    count++;
                    mRefelect = true;
                    mCount_result.setText(count + "");
                } else {
                    add.setSelected(true);
                }
                break;
            case R.id.reduce_goodsNum:
                add.setSelected(false);
                if (count <= Integer.parseInt(min)) {
                    reduce.setSelected(true);
                } else {
                    count--;
                    mRefelect = true;
                    mCount_result.setText(count + "");
                    reduce.setSelected(false);
                }
                break;
            default:
                break;
        }
    }

    /**
     * @param value 设置显示的值
     */
    public void setText(String value, boolean refelect) {
        mRefelect = refelect;
        mCount_result.setText(value);
        if (Integer.parseInt(value) >= Integer.parseInt(max)) {
            add.setSelected(true);
        } else {
            add.setSelected(false);
        }

        if (Integer.parseInt(value) <= Integer.parseInt(min)) {
            reduce.setSelected(true);
        } else {
            reduce.setSelected(false);
        }
    }

    public void setMax(String max) {
        this.max = max;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public interface OnClick {
        void onClick(CountView view, int count);
    }

    public void setOnClick(OnClick click) {

        mClick = click;
    }
}
