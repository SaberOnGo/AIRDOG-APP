package com.gizwits.opensource.appkit;

import android.app.Application;

import com.tencent.bugly.Bugly;
import com.tencent.bugly.beta.Beta;

public class GosApplication extends Application {

    public static int flag = 0;

    public void onCreate() {
        super.onCreate();

        //bugly
        Beta.autoCheckUpgrade = false;
        Bugly.init(getApplicationContext(), "73856c2f9c", BuildConfig.DEBUG);
    }


}
