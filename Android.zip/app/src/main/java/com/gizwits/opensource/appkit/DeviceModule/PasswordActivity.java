package com.gizwits.opensource.appkit.DeviceModule;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.gizwits.opensource.appkit.CommonModule.GosBaseActivity;
import com.gizwits.opensource.appkit.R;

public class PasswordActivity extends GosBaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);
        setToolBar(true,"修改操作密码");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onChangePasswordClick(View view){
        TextView oldText = findViewById(R.id.oldPasswordText);
        String oldPassword = spf.getString("op_passwd",null);
        if (oldPassword.equals(oldText.getText().toString())){
            TextView newPasswordText = findViewById(R.id.newPasswordText);
            String pwd = newPasswordText.getText().toString();
            if (!TextUtils.isEmpty(pwd)){
                spf.edit()
                        .putString("op_passwd",pwd)
                        .putBoolean("dev_ok",false)
                        .commit();
                finish();
            }else {
                Toast.makeText(this,"新密码错误",Toast.LENGTH_SHORT).show();
            }
        }else {
            Toast.makeText(this,"密码错误",Toast.LENGTH_SHORT).show();
        }
    }

}
