package com.gizwits.opensource.appkit.ControlModule;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import com.gizwits.gizwifisdk.api.GizWifiDevice;
import com.gizwits.gizwifisdk.enumration.GizWifiDeviceNetStatus;
import com.gizwits.gizwifisdk.enumration.GizWifiErrorCode;
import com.gizwits.opensource.appkit.CommonModule.GosDeploy;
import com.gizwits.opensource.appkit.R;
import com.gizwits.opensource.appkit.utils.HexStrUtils;
import com.gizwits.opensource.appkit.view.CountView;

import java.util.concurrent.ConcurrentHashMap;

import static com.gizwits.opensource.appkit.utils.HexStrUtils.splitBytesString;

public class GosDeviceControlActivity extends GosControlModuleBaseActivity
        implements OnClickListener, OnEditorActionListener, OnSeekBarChangeListener, CountView.OnClick {

    private static final String TAG = "GosDeviceControl";

//    /**
//     * 设备列表传入的设备变量
//     */
//    private GizWifiDevice mDevice;

    private Switch sw_bool_RF_State;
    private Switch sw_bool_MC_State;
//    private Switch sw_bool_ShutOff;
    private CountView tv_data_WorkMode;
    private SeekBar sb_data_WorkMode;
    private CountView tv_data_RF_Level;
    private SeekBar sb_data_RF_Level;
    private CountView tv_data_MC_Level;
    private SeekBar sb_data_MC_Level;
    private CountView tv_data_RF_Time;
    private SeekBar sb_data_RF_Time;
    private CountView tv_data_MC_Time;
    private SeekBar sb_data_MC_Time;
    private TextView tv_data_HandleTotalCounter;
    private TextView tv_data_HandleFunction;
    private TextView tv_extend_HandleSN;
    private TextView tv_extend_HandleDate;
    private TextView tv_extend_HandleCode;
//    private Button btn_RF_MC_State;
    private Button btn_start_stop;
    private Button btn_RF_State;
    private Button btn_MC_State;


    private enum handler_key {

        /**
         * 更新界面
         */
        UPDATE_UI,

        DISCONNECT,
    }

    private Runnable mRunnable = new Runnable() {
        public void run() {
            if (isDeviceCanBeControlled()) {
                progressDialog.cancel();
            } else {
                toastDeviceNoReadyAndExit();
            }
        }

    };

    /**
     * The handler.
     */
    Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            handler_key key = handler_key.values()[msg.what];
            switch (key) {
                case UPDATE_UI:
                    updateUI();
                    break;
                case DISCONNECT:
                    toastDeviceDisconnectAndExit();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gos_device_control);
//        initDevice();
        setToolBar(true, getDeviceName(mDevice));
        final Drawable add = getResources().getDrawable(R.drawable.common_setting_more);
        int color = GosDeploy.appConfig_Contrast();
        add.setColorFilter(color, PorterDuff.Mode.SRC_ATOP);
        mToolbar.setOverflowIcon(add);
        initView();
        initConfig();
        initEvent();

        boolean isOk = spf.getBoolean("dev_ok",false);
        if (!isOk){
            EditText editText = new EditText(this);
            editText.setHint("请输入操作密码");
            new AlertDialog.Builder(this)
                    .setTitle("操作密码")
                    .setView(editText)
                    .setCancelable(false)
                    .setPositiveButton(android.R.string.ok,(dialog, which) -> {
                        String pwd = spf.getString("op_passwd",null);
                        if (pwd.equals(editText.getText().toString())){
                            spf.edit().putBoolean("dev_ok",true).commit();
                            updateUI();
                        }
                    })
                    .setNegativeButton(android.R.string.cancel,null)
                    .show();
        }
        updateUI();
    }

    private void initConfig() {
        tv_data_WorkMode.setMax("2");
        tv_data_WorkMode.setMin("1");
        tv_data_RF_Level.setMax("5");
        tv_data_RF_Level.setMin("1");
        tv_data_MC_Level.setMax("3");
        tv_data_MC_Level.setMin("1");
        tv_data_RF_Time.setMax("60");
        tv_data_RF_Time.setMin("0");
        tv_data_MC_Time.setMax("60");
        tv_data_MC_Time.setMin("0");
    }

    private void initView() {

        sw_bool_RF_State = (Switch) findViewById(R.id.sw_bool_RF_State);
        sw_bool_MC_State = (Switch) findViewById(R.id.sw_bool_MC_State);
//        sw_bool_ShutOff = (Switch) findViewById(R.id.sw_bool_ShutOff);
        tv_data_WorkMode = (CountView) findViewById(R.id.tv_data_WorkMode);
        sb_data_WorkMode = (SeekBar) findViewById(R.id.sb_data_WorkMode);
        tv_data_RF_Level = (CountView) findViewById(R.id.tv_data_RF_Level);
        sb_data_RF_Level = (SeekBar) findViewById(R.id.sb_data_RF_Level);
        tv_data_MC_Level = (CountView) findViewById(R.id.tv_data_MC_Level);
        sb_data_MC_Level = (SeekBar) findViewById(R.id.sb_data_MC_Level);
        tv_data_RF_Time = (CountView) findViewById(R.id.tv_data_RF_Time);
        sb_data_RF_Time = (SeekBar) findViewById(R.id.sb_data_RF_Time);
        tv_data_MC_Time = (CountView) findViewById(R.id.tv_data_MC_Time);
        sb_data_MC_Time = (SeekBar) findViewById(R.id.sb_data_MC_Time);
        tv_data_HandleTotalCounter = (TextView) findViewById(R.id.tv_data_HandleTotalCounter);
        tv_data_HandleFunction = (TextView) findViewById(R.id.tv_data_HandleFunction);
        tv_extend_HandleSN = (TextView) findViewById(R.id.tv_extend_HandleSN);
        tv_extend_HandleDate = (TextView) findViewById(R.id.tv_extend_HandleDate);
        tv_extend_HandleCode = (TextView) findViewById(R.id.tv_extend_HandleCode);
//        btn_RF_MC_State = (Button) findViewById(R.id.btn_RF_MC_State);
        btn_start_stop = (Button) findViewById(R.id.btn_start_stop);
        btn_RF_State = findViewById(R.id.btn_RF_State);
        btn_MC_State = findViewById(R.id.btn_MC_State);
    }

    private void initEvent() {

        sw_bool_RF_State.setOnClickListener(this);
        sw_bool_MC_State.setOnClickListener(this);
//        sw_bool_ShutOff.setOnClickListener(this);
        sb_data_WorkMode.setOnSeekBarChangeListener(this);
        sb_data_RF_Level.setOnSeekBarChangeListener(this);
        sb_data_MC_Level.setOnSeekBarChangeListener(this);
        sb_data_RF_Time.setOnSeekBarChangeListener(this);
        sb_data_MC_Time.setOnSeekBarChangeListener(this);
        tv_data_WorkMode.setOnClick(this);
        tv_data_RF_Level.setOnClick(this);
        tv_data_MC_Level.setOnClick(this);
        tv_data_RF_Time.setOnClick(this);
        tv_data_MC_Time.setOnClick(this);
//        btn_RF_MC_State.setOnClickListener(this);
        btn_start_stop.setOnClickListener(this);
        btn_MC_State.setOnClickListener(this);
        btn_RF_State.setOnClickListener(this);

    }

//    private void initDevice() {
//        Intent intent = getIntent();
//        mDevice = (GizWifiDevice) intent.getParcelableExtra("GizWifiDevice");
//        mDevice.setListener(gizWifiDeviceListener);
//        Log.i("Apptest", mDevice.getDid());
//    }

    private String getDeviceName(GizWifiDevice device) {
        if (TextUtils.isEmpty(device.getAlias())) {
            String m = device.getMacAddress().substring(device.getMacAddress().length() - 2);
            return device.getProductName()+"_"+m;
        }
        return device.getAlias();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getStatusOfDevice();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacks(mRunnable);
//        // 退出页面，取消设备订阅
        mDevice.setSubscribe(false);
        mDevice.setListener(null);
    }

    private long lastClickTime = 0L;
    private static final int FAST_CLICK_DELAY_TIME = 3000;  // 快速点击间隔

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.sw_bool_RF_State:
                sendCommand(KEY_RF_STATE, sw_bool_RF_State.isChecked());
                break;
            case R.id.sw_bool_MC_State:
                sendCommand(KEY_MC_STATE, sw_bool_MC_State.isChecked());
                break;
//            case R.id.sw_bool_ShutOff:
//                sendCommand(KEY_SHUTOFF, sw_bool_ShutOff.isChecked());
//                break;
//            case R.id.btn_RF_MC_State:
//                if (System.currentTimeMillis() - lastClickTime < FAST_CLICK_DELAY_TIME) {
//                    return;
//                }
//                lastClickTime = System.currentTimeMillis();
//                if (data_WorkMode == 1) {
//                    //RF——>MC
//                    sendCommand(KEY_WORKMODE, 2);
//                    if (data_MC_State) {
//                        //Stop ——> Start
//                        sendCommand(KEY_MC_STATE, false);
//                    }
//                } else if (data_WorkMode == 2) {
//                    //MC——>RF
//                    sendCommand(KEY_WORKMODE, 1);
//                    if (data_RF_State) {
//                        //Stop ——> Start
//                        sendCommand(KEY_RF_STATE, false);
//                    }
//                }
//                break;
            case R.id.btn_RF_State:
                sendCommand(KEY_WORKMODE, 1);
//                if (data_MC_State) {
//                    //Stop ——> Start
//                    sendCommand(KEY_MC_STATE, false);
//                }
                break;
            case R.id.btn_MC_State:
                sendCommand(KEY_WORKMODE, 2);
//                if (data_RF_State) {
//                    //Stop ——> Start
//                    sendCommand(KEY_RF_STATE, false);
//                }
                break;
            case R.id.btn_start_stop:
                if (System.currentTimeMillis() - lastClickTime < FAST_CLICK_DELAY_TIME) {
                    return;
                }
                lastClickTime = System.currentTimeMillis();
                if (data_WorkMode == 1) {
                    //RF_State
                    sendCommand(KEY_RF_STATE, !data_RF_State);
                } else if (data_WorkMode == 2) {
                    //MC_State
                    sendCommand(KEY_MC_STATE, !data_MC_State);
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onClick(CountView view, int count) {
        switch (view.getId()) {
            case R.id.tv_data_WorkMode:
                sendCommand(KEY_WORKMODE, count);
                break;
            case R.id.tv_data_RF_Level:
                sendCommand(KEY_RF_LEVEL, count);
                break;
            case R.id.tv_data_MC_Level:
                sendCommand(KEY_MC_LEVEL, count);
                break;
            case R.id.tv_data_RF_Time:
                sendCommand(KEY_RF_TIME, count);
                break;
            case R.id.tv_data_MC_Time:
                sendCommand(KEY_MC_TIME, count);
                break;
            default:
                break;
        }
    }

    /*
     * ========================================================================
     * EditText 点击键盘“完成”按钮方法
     * ========================================================================
     */
    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

        switch (v.getId()) {
            default:
                break;
        }
        hideKeyBoard();
        return false;

    }

    /*
     * ========================================================================
     * seekbar 回调方法重写
     * ========================================================================
     */
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

        switch (seekBar.getId()) {
            case R.id.sb_data_WorkMode:
                tv_data_WorkMode.setText(formatValue((progress + WORKMODE_OFFSET) * WORKMODE_RATIO + WORKMODE_ADDITION, 1), false);
                break;
            case R.id.sb_data_RF_Level:
                tv_data_RF_Level.setText(formatValue((progress + RF_LEVEL_OFFSET) * RF_LEVEL_RATIO + RF_LEVEL_ADDITION, 1), false);
                break;
            case R.id.sb_data_MC_Level:
                tv_data_MC_Level.setText(formatValue((progress + MC_LEVEL_OFFSET) * MC_LEVEL_RATIO + MC_LEVEL_ADDITION, 1), false);
                break;
            case R.id.sb_data_RF_Time:
                tv_data_RF_Time.setText(formatValue((progress + RF_TIME_OFFSET) * RF_TIME_RATIO + RF_TIME_ADDITION, 1), false);
                break;
            case R.id.sb_data_MC_Time:
                tv_data_MC_Time.setText(formatValue((progress + MC_TIME_OFFSET) * MC_TIME_RATIO + MC_TIME_ADDITION, 1), false);
                break;
            default:
                break;
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        switch (seekBar.getId()) {
            case R.id.sb_data_WorkMode:
                sendCommand(KEY_WORKMODE, (seekBar.getProgress() + WORKMODE_OFFSET) * WORKMODE_RATIO + WORKMODE_ADDITION);
                break;
            case R.id.sb_data_RF_Level:
                sendCommand(KEY_RF_LEVEL, (seekBar.getProgress() + RF_LEVEL_OFFSET) * RF_LEVEL_RATIO + RF_LEVEL_ADDITION);
                break;
            case R.id.sb_data_MC_Level:
                sendCommand(KEY_MC_LEVEL, (seekBar.getProgress() + MC_LEVEL_OFFSET) * MC_LEVEL_RATIO + MC_LEVEL_ADDITION);
                break;
            case R.id.sb_data_RF_Time:
                sendCommand(KEY_RF_TIME, (seekBar.getProgress() + RF_TIME_OFFSET) * RF_TIME_RATIO + RF_TIME_ADDITION);
                break;
            case R.id.sb_data_MC_Time:
                sendCommand(KEY_MC_TIME, (seekBar.getProgress() + MC_TIME_OFFSET) * MC_TIME_RATIO + MC_TIME_ADDITION);
                break;
            default:
                break;
        }
    }

    /*
     * ========================================================================
     * 菜单栏
     * ========================================================================
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.device_more, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_setDeviceInfo:
                setDeviceInfo();
                break;

            case R.id.action_getHardwareInfo:
                if (mDevice.isLAN()) {
                    mDevice.getHardwareInfo();
                } else {
                    myToast("只允许在局域网下获取设备硬件信息！");
                }
                break;

            case R.id.action_getStatu:
                mDevice.getDeviceStatus();
                break;
            case R.id.action_setting:
                boolean isOk = spf.getBoolean("dev_ok",false);
                if (isOk){
                    startActivity(new Intent(this,GosDeviceSettingActivity.class));
                }

                break;
            default:
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Description:根据保存的的数据点的值来更新UI
     */
    protected void updateUI() {

         if (data_WorkMode == 1) {
//            btn_RF_MC_State.setText("Micro Current");
            btn_RF_State.setSelected(true);
            btn_MC_State.setSelected(false);
             btn_start_stop.setSelected(data_RF_State);
             btn_start_stop.setText(btn_start_stop.isSelected()?"Stop":"Start");
//            if (data_RF_State) {
//                btn_start_stop.setSelected(true);
//                btn_start_stop.setText("Stop");
//            } else {
//                btn_start_stop.setSelected(false);
//                btn_start_stop.setText("Start");
//            }
        } else {
//            btn_RF_MC_State.setText("RF");
             btn_RF_State.setSelected(false);
             btn_MC_State.setSelected(true);
             btn_start_stop.setSelected(data_MC_State);
             btn_start_stop.setText(btn_start_stop.isSelected()?"Stop":"Start");
//             if (data_MC_State) {
//                 btn_start_stop.setSelected(true);
//                 btn_start_stop.setText("Stop");
//             } else {
//                 btn_start_stop.setSelected(false);
//                 btn_start_stop.setText("Start");
//             }
         }

        sw_bool_RF_State.setChecked(data_RF_State);
        sw_bool_MC_State.setChecked(data_MC_State);
//        sw_bool_ShutOff.setChecked(data_ShutOff);
        tv_data_WorkMode.setText(data_WorkMode + "", false);
        sb_data_WorkMode.setProgress((int) ((data_WorkMode - WORKMODE_ADDITION) / WORKMODE_RATIO - WORKMODE_OFFSET));
        tv_data_RF_Level.setText(data_RF_Level + "", false);
        sb_data_RF_Level.setProgress((int) ((data_RF_Level - RF_LEVEL_ADDITION) / RF_LEVEL_RATIO - RF_LEVEL_OFFSET));
        tv_data_MC_Level.setText(data_MC_Level + "", false);
        sb_data_MC_Level.setProgress((int) ((data_MC_Level - MC_LEVEL_ADDITION) / MC_LEVEL_RATIO - MC_LEVEL_OFFSET));
        tv_data_RF_Time.setText(data_RF_Time + "", false);
        sb_data_RF_Time.setProgress((int) ((data_RF_Time - RF_TIME_ADDITION) / RF_TIME_RATIO - RF_TIME_OFFSET));
        tv_data_MC_Time.setText(data_MC_Time + "", false);
        sb_data_MC_Time.setProgress((int) ((data_MC_Time - MC_TIME_ADDITION) / MC_TIME_RATIO - MC_TIME_OFFSET));
        tv_data_HandleTotalCounter.setText(data_HandleTotalCounter + "");
        tv_data_HandleFunction.setText(data_HandleFunction + "");


        String hexDate = splitBytesString(HexStrUtils.bytesToHexString(data_HandleDate));
        String hexCode = splitBytesString(HexStrUtils.bytesToHexString(data_HandleCode));
        String hexSn = HexStrUtils.splitBytesString(HexStrUtils.bytesToHexString(data_HandleSN));
        tv_extend_HandleSN.setText(HexStrUtils.hexStringToString(hexSn));
        tv_extend_HandleDate.setText(HexStrUtils.hexStringToString(hexDate));
        tv_extend_HandleCode.setText(HexStrUtils.hexStringToString(hexCode));

//        if (data_RF_State){
//            findViewById(R.id.RF_Level_View).setVisibility(View.VISIBLE);
//            findViewById(R.id.RF_Time_View).setVisibility(View.VISIBLE);
//            findViewById(R.id.MC_Level_View).setVisibility(View.GONE);
//            findViewById(R.id.MC_Time_View).setVisibility(View.GONE);
//        }
//        else {
//            findViewById(R.id.RF_Level_View).setVisibility(View.GONE);
//            findViewById(R.id.RF_Time_View).setVisibility(View.GONE);
//            findViewById(R.id.MC_Level_View).setVisibility(View.VISIBLE);
//            findViewById(R.id.MC_Time_View).setVisibility(View.VISIBLE);
//        }


        if (data_WorkMode == 1 ){
            findViewById(R.id.RF_Level_View).setVisibility(View.VISIBLE);
            findViewById(R.id.RF_Time_View).setVisibility(View.VISIBLE);
            findViewById(R.id.MC_Level_View).setVisibility(View.GONE);
            findViewById(R.id.MC_Time_View).setVisibility(View.GONE);
        } else {
            findViewById(R.id.RF_Level_View).setVisibility(View.GONE);
            findViewById(R.id.RF_Time_View).setVisibility(View.GONE);
            findViewById(R.id.MC_Level_View).setVisibility(View.VISIBLE);
            findViewById(R.id.MC_Time_View).setVisibility(View.VISIBLE);
        }

        boolean enabled = data_WorkMode == 1 ? data_RF_State : data_MC_State;
        boolean isOk = spf.getBoolean("dev_ok",false);
        btn_start_stop.setEnabled(isOk);
//        sb_data_WorkMode.setEnabled(isOk);
        isOk = isOk && (!enabled);

        sb_data_RF_Time.setEnabled(isOk);
        sb_data_MC_Time.setEnabled(isOk);
        sb_data_MC_Level.setEnabled(isOk);
        sb_data_RF_Level.setEnabled(isOk);
        btn_MC_State.setEnabled(isOk);
        btn_RF_State.setEnabled(isOk);

        tv_data_RF_Level.setEnabled(isOk);
        tv_data_RF_Level.findViewById(R.id.increase_goods_Num).setEnabled(isOk);
        tv_data_RF_Level.findViewById(R.id.reduce_goodsNum).setEnabled(isOk);
        tv_data_RF_Level.findViewById(R.id.change_number).setEnabled(isOk);

        tv_data_RF_Time.setEnabled(isOk);
        tv_data_RF_Time.findViewById(R.id.increase_goods_Num).setEnabled(isOk);
        tv_data_RF_Time.findViewById(R.id.reduce_goodsNum).setEnabled(isOk);
        tv_data_RF_Time.findViewById(R.id.change_number).setEnabled(isOk);

        tv_data_MC_Level.setEnabled(isOk);
        tv_data_MC_Level.findViewById(R.id.increase_goods_Num).setEnabled(isOk);
        tv_data_MC_Level.findViewById(R.id.reduce_goodsNum).setEnabled(isOk);
        tv_data_MC_Level.findViewById(R.id.change_number).setEnabled(isOk);

        tv_data_MC_Time.setEnabled(isOk);
        tv_data_MC_Time.findViewById(R.id.increase_goods_Num).setEnabled(isOk);
        tv_data_MC_Time.findViewById(R.id.reduce_goodsNum).setEnabled(isOk);
        tv_data_MC_Time.findViewById(R.id.change_number).setEnabled(isOk);

    }

    private void setEditText(EditText et, Object value) {
        et.setText(value.toString());
        et.setSelection(value.toString().length());
        et.clearFocus();
    }

    /**
     * Description:页面加载后弹出等待框，等待设备可被控制状态回调，如果一直不可被控，等待一段时间后自动退出界面
     */
    private void getStatusOfDevice() {
        // 设备是否可控
        if (isDeviceCanBeControlled()) {
            // 可控则查询当前设备状态
            mDevice.getDeviceStatus();
        } else {
            // 显示等待栏
            progressDialog.show();
            if (mDevice.isLAN()) {
                // 小循环10s未连接上设备自动退出
                mHandler.postDelayed(mRunnable, 10000);
            } else {
                // 大循环20s未连接上设备自动退出
                mHandler.postDelayed(mRunnable, 20000);
            }
        }
    }


    private boolean isDeviceCanBeControlled() {
        return mDevice.getNetStatus() == GizWifiDeviceNetStatus.GizDeviceControlled;
    }

    private void toastDeviceNoReadyAndExit() {
        Toast.makeText(this, "设备无响应，请检查设备是否正常工作", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void toastDeviceDisconnectAndExit() {
        Toast.makeText(GosDeviceControlActivity.this, "连接已断开", Toast.LENGTH_SHORT).show();
//        finish();
    }

    /**
     * 展示设备硬件信息
     *
     * @param hardwareInfo
     */
    private void showHardwareInfo(String hardwareInfo) {
        String hardwareInfoTitle = "设备硬件信息";
        new AlertDialog.Builder(this).setTitle(hardwareInfoTitle).setMessage(hardwareInfo)
                .setPositiveButton(R.string.besure, null).show();
    }

    /**
     * Description:设置设备别名与备注
     */
    private void setDeviceInfo() {

        final Dialog mDialog = new AlertDialog.Builder(this, R.style.edit_dialog_style).setView(new EditText(this)).create();
        mDialog.show();

        Window window = mDialog.getWindow();
        window.setContentView(R.layout.alert_gos_set_device_info);
        WindowManager.LayoutParams layoutParams = window.getAttributes();
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
        window.setAttributes(layoutParams);
        final EditText etAlias;
        final EditText etRemark;
        etAlias = (EditText) window.findViewById(R.id.etAlias);
        etRemark = (EditText) window.findViewById(R.id.etRemark);

        LinearLayout llNo, llSure;
        llNo = (LinearLayout) window.findViewById(R.id.llNo);
        llSure = (LinearLayout) window.findViewById(R.id.llSure);

        if (!TextUtils.isEmpty(mDevice.getAlias())) {
            setEditText(etAlias, mDevice.getAlias());
        }
        if (!TextUtils.isEmpty(mDevice.getRemark())) {
            setEditText(etRemark, mDevice.getRemark());
        }

        llNo.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });

        llSure.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(etRemark.getText().toString())
                        && TextUtils.isEmpty(etAlias.getText().toString())) {
                    myToast("请输入设备别名或备注！");
                    return;
                }
                mDevice.setCustomInfo(etRemark.getText().toString(), etAlias.getText().toString());
                mDialog.dismiss();
                String loadingText = (String) getText(R.string.loadingtext);
                progressDialog.setMessage(loadingText);
                progressDialog.show();
            }
        });
    }

    /*
     * 获取设备硬件信息回调
     */
    @Override
    protected void didGetHardwareInfo(GizWifiErrorCode result, GizWifiDevice device,
                                      ConcurrentHashMap<String, String> hardwareInfo) {
        super.didGetHardwareInfo(result, device, hardwareInfo);
        StringBuffer sb = new StringBuffer();
        if (GizWifiErrorCode.GIZ_SDK_SUCCESS != result) {
            myToast("获取设备硬件信息失败：" + result.name());
        } else {
            sb.append("Wifi Hardware Version:" + hardwareInfo.get(WIFI_HARDVER_KEY) + "\r\n");
            sb.append("Wifi Software Version:" + hardwareInfo.get(WIFI_SOFTVER_KEY) + "\r\n");
            sb.append("MCU Hardware Version:" + hardwareInfo.get(MCU_HARDVER_KEY) + "\r\n");
            sb.append("MCU Software Version:" + hardwareInfo.get(MCU_SOFTVER_KEY) + "\r\n");
            sb.append("Wifi Firmware Id:" + hardwareInfo.get(WIFI_FIRMWAREID_KEY) + "\r\n");
            sb.append("Wifi Firmware Version:" + hardwareInfo.get(WIFI_FIRMWAREVER_KEY) + "\r\n");
            sb.append("Product Key:" + "\r\n" + hardwareInfo.get(PRODUCT_KEY) + "\r\n");

            // 设备属性
            sb.append("Device ID:" + "\r\n" + mDevice.getDid() + "\r\n");
            sb.append("Device IP:" + mDevice.getIPAddress() + "\r\n");
            sb.append("Device MAC:" + mDevice.getMacAddress() + "\r\n");
        }
        showHardwareInfo(sb.toString());
    }

    /*
     * 设置设备别名和备注回调
     */
    @Override
    protected void didSetCustomInfo(GizWifiErrorCode result, GizWifiDevice device) {
        super.didSetCustomInfo(result, device);
        if (GizWifiErrorCode.GIZ_SDK_SUCCESS == result) {
            myToast("设置成功");
            progressDialog.cancel();
//            finish();
            setToolBar(true, getDeviceName(device));
        } else {
            myToast("设置失败：" + result.name());
        }
    }

    /*
     * 设备状态改变回调，只有设备状态为可控才可以下发控制命令
     */
    @Override
    protected void didUpdateNetStatus(GizWifiDevice device, GizWifiDeviceNetStatus netStatus) {
        super.didUpdateNetStatus(device, netStatus);
        if (netStatus == GizWifiDeviceNetStatus.GizDeviceControlled) {
            mHandler.removeCallbacks(mRunnable);
            progressDialog.cancel();
        } else {
            mHandler.sendEmptyMessage(handler_key.DISCONNECT.ordinal());
        }
    }

    /*
     * 设备上报数据回调，此回调包括设备主动上报数据、下发控制命令成功后设备返回ACK
     */
    @Override
    protected void didReceiveData(GizWifiErrorCode result, GizWifiDevice device,
                                  ConcurrentHashMap<String, Object> dataMap, int sn) {
        super.didReceiveData(result, device, dataMap, sn);
        Log.i(TAG, "接收到数据");
        if (result == GizWifiErrorCode.GIZ_SDK_SUCCESS && dataMap.get("data") != null) {
            getDataFromReceiveDataMap(dataMap);
            mHandler.sendEmptyMessage(handler_key.UPDATE_UI.ordinal());
        }
    }

}