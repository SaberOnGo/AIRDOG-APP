package com.gizwits.opensource.appkit.ControlModule;

import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Switch;

import com.gizwits.gizwifisdk.api.GizWifiDevice;
import com.gizwits.gizwifisdk.enumration.GizWifiErrorCode;
import com.gizwits.opensource.appkit.R;

import java.util.concurrent.ConcurrentHashMap;

public class GosDeviceSettingActivity extends GosControlModuleBaseActivity {

    private Switch sw_bool_ShutOff;
    private Handler mHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gos_device_setting);
        setToolBar(true, "高级设置");

        sw_bool_ShutOff = (Switch) findViewById(R.id.sw_bool_ShutOff);
        sw_bool_ShutOff.setOnClickListener(v -> {
            String msg = sw_bool_ShutOff.isChecked()?"This will lock the system.":"This will unlock the system.";
            new AlertDialog.Builder(v.getContext())
                    .setTitle(msg)
                    .setPositiveButton(android.R.string.ok,(dialog, which) -> {
                        sendCommand(KEY_SHUTOFF, sw_bool_ShutOff.isChecked());
                    })
                    .setNegativeButton(android.R.string.cancel,(dialog, which) -> {
                        sw_bool_ShutOff.setChecked(!sw_bool_ShutOff.isChecked());
                    })
                    .create()
                    .show();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        mDevice.getDeviceStatus();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void didReceiveData(GizWifiErrorCode result, GizWifiDevice device, ConcurrentHashMap<String, Object> dataMap, int sn) {
        super.didReceiveData(result, device, dataMap, sn);
        Log.i("GosDeviceSetting", "接收到数据");
        if (result == GizWifiErrorCode.GIZ_SDK_SUCCESS && dataMap.get("data") != null) {
            getDataFromReceiveDataMap(dataMap);
//            mHandler.sendEmptyMessage(GosDeviceControlActivity.handler_key.UPDATE_UI.ordinal());
            mHandler.post(()->{
                sw_bool_ShutOff.setChecked(data_ShutOff);
            });
        }
    }
}
